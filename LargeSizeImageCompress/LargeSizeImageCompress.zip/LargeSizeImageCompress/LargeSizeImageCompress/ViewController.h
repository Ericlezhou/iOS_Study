//
//  ViewController.h
//  LargeSizeImageCompress
//
//  Created by Eric on 2018/5/25.
//  Copyright © 2018年 nexus. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

